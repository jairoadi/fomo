CREATE FUNCTION int8pl_inet (bigint, inet) RETURNS inet
	LANGUAGE sql
AS $$
select $2 + $1
$$
