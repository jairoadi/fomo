CREATE FUNCTION interval_pl_timestamptz (interval, timestamp with time zone) RETURNS timestamp with time zone
	LANGUAGE sql
AS $$
select $2 + $1
$$
